**Documentation**
API documentation is currently available in HTML at [http://www.rufelt.com/fw1fontwrapper/](http://www.rufelt.com/fw1fontwrapper/).

**Minimal C++ code example**
Drawing strings on the screen is easily achieved in a few lines of code. See the downloadable samples for additional feature examples.

{code:c++}
#include "FW1FontWrapper.h"

void drawText(ID3D11Device **pDevice, ID3D11DeviceContext **pContext) {
	IFW1Factory *pFW1Factory;
	HRESULT hResult = FW1CreateFactory(FW1_VERSION, &pFW1Factory);
	
	IFW1FontWrapper *pFontWrapper;
	hResult = pFW1Factory->CreateFontWrapper(pDevice, L"Arial", &pFontWrapper);
	
	pFontWrapper->DrawString(
		pContext,
		L"Text",// String
		128.0f,// Font size
		100.0f,// X position
		50.0f,// Y position
		0xff0099ff,// Text color, 0xAaBbGgRr
		0// Flags (for example FW1_RESTORESTATE to keep context states unchanged)
	);
	
	pFontWrapper->Release();
	pFW1Factory->Release();
}
{code:c++}
