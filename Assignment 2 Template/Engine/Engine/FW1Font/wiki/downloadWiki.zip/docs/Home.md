**Project Description**
FW1FontWrapper is a font wrapper library for drawing text using Direct3D 11. It uses DirectWrite for formatting, text layout, and glyph caching, exposing basic DirectWrite text functionality for use with a D3D11 render target.
The library is written in C++, and either compiles to a DLL or can be statically included in a project directly.
